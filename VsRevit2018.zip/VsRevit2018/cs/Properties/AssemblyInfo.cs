using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Just info about the project.
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription( "Standard Revit Add-In Description for $projectname$" )]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("BIM2")]
[assembly: AssemblyProduct( "$projectname$ Revit C# .NET Add-In" )]
[assembly: AssemblyCopyright( "Copyright 2019 (C) James Simpson, BIM�" )]

// The GUID of the project
[assembly: Guid("2620bc3f-e283-4d99-89c7-31eee9eadba8")]

// Assembly version
[assembly: AssemblyVersion("2018.1.0.0")]
[assembly: AssemblyFileVersion("2018.1.0.0")]
