#region Usings
//Standard Using statments for our code
using System;
using System.Windows.Forms;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Application = Autodesk.Revit.ApplicationServices.Application;
using System.Reflection;
using Autodesk.Revit.DB.Events;
using System.Windows.Media.Imaging;
using System.IO;
#endregion

namespace $safeprojectname$.Ribbon
{
    //are addin must be defined as a standalone application (that obviously links into Revit as well)
    class RibbonApp : IExternalApplication
    {
        //when the addin (application) starts
        public Result OnStartup(UIControlledApplication application)
        {
            // call your method that will load your ribbon
            AddRibbonPanel(application);
            //return success
            return Result.Succeeded;
        }
        //when it closes
        public Result OnShutdown(UIControlledApplication a)
        {
            //close normally
            return Result.Succeeded;
        }
        //method to add the Ribbon Panel
        static void AddRibbonPanel(UIControlledApplication application)
        {
            // Create a custom ribbon tab
            String tabName = "My Ribbon";
            application.CreateRibbonTab(tabName);

            // Get dll assembly path
            string thisAssemblyPath = Assembly.GetExecutingAssembly().Location;

            // Add a new ribbon panel
            RibbonPanel ribbonPanel = application.CreateRibbonPanel(tabName, "My Panel");

            // create push button for First Command
            PushButtonData bData = new PushButtonData(
                "CmdBtn",
                "1st" + System.Environment.NewLine + "  Command  ",
                thisAssemblyPath,
                "$safeprojectname$.Command.FirstCommand");
            //create push button from data
            PushButton pb1 = ribbonPanel.AddItem(bData) as PushButton;
            //add image for button
            BitmapImage pb1Image = new BitmapImage(new Uri(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),"Resources", "BIM².Ico")));
            pb1.LargeImage = pb1Image;
            //add tooltip info
            pb1.ToolTip = "Just an example of tooltip info you can include";
            //add image for tooltip
            System.Windows.Media.ImageSource ttImage = pb1Image;
            pb1.ToolTipImage = ttImage;
            //add help for tooltip
            pb1.SetContextualHelp(new ContextualHelp(ContextualHelpType.Url, "https://bimsquared.com"));
        }
    }
}