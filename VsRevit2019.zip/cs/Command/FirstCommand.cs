#region Usings
//all our standard using statments for our code
using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

#endregion


namespace $safeprojectname$.Command
{
    //dictates that we will be setting our own transactions. Allows for more control and is good practice
    [Transaction(TransactionMode.Manual)]
    //define our class as a command
    //this is the only way to call a command in Revit
    public class FirstCommand : IExternalCommand
    {
        //An IExternal command must have an execute method.
        //This is the method that is called when calling the command.
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //set up document space
            //each allows you access to seperate methods of RevitAPI
            var uiapp = commandData.Application;
            var uidoc = uiapp.ActiveUIDocument;
            var app = uiapp.Application;
            var doc = uidoc.Document;
            //Transactions-
            //Transactions must be initiatied to make any changes to Revit.
            //Usings
            //Wrapping transactions in a using statment is also good practice.
            //This allows for them to be released in the code when finished.
            using (var trans = new Transaction(doc))
            {
                //starts the transcation
                trans.Start("Temp Trans");
                {
                    //try catch statements are techinally not needed inside usings
                    //however it allows you to trap errors and handle them accordingly if need be 
                    try
                    {
                        // prompt user for element
                        var eref = uidoc.Selection.PickObject(ObjectType.Element, "Select an object");
                        //create a quick prompt
                        var ts = new TaskDialog("Test Dialogue")
                        {
                            //tell it to show the selected elements name
                            MainContent = doc.GetElement(eref).Name
                        };
                        //display the dialog
                        ts.Show();
                        //commit the changes
                        trans.Commit();
                        //return success
                        return Result.Succeeded;
                    }
                    //catch failures
                    catch (Exception)
                    {
                        //undo changes
                        trans.RollBack();
                        //return failed
                        return Result.Failed;
                    }
                }
            }
        }
    }
}
