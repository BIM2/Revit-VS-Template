#region Usings
//Standard Using statments for our code
using System;
using System.IO;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Autodesk.Revit.UI;

#endregion

namespace $safeprojectname$.Ribbon
{
    //our addin must be defined as a standalone application (that obviously links into Revit as well)
    internal class RibbonApp : IExternalApplication
    {
        //when the addin (application) starts
        public Result OnStartup(UIControlledApplication application)
        {
            // call your method that will load your ribbon
            AddRibbonPanel(application);
            //return success
            return Result.Succeeded;
        }
        //when it closes
        public Result OnShutdown(UIControlledApplication a)
        {
            //close normally
            return Result.Succeeded;
        }
        //method to add the Ribbon Panel
        private static void AddRibbonPanel(UIControlledApplication application)
        {
            // Create a custom ribbon tab
            const String tabName = "My Ribbon";
            application.CreateRibbonTab(tabName);

            // Get dll assembly path
            var thisAssemblyPath = Assembly.GetExecutingAssembly().Location;

            // Add a new ribbon panel
            var ribbonPanel = application.CreateRibbonPanel(tabName, "My Panel");

            // create push button for First Command
            var bData = new PushButtonData(
                "CmdBtn",
                "1st" + Environment.NewLine + "  Command  ",
                thisAssemblyPath,
                "Revit2019Addin.Command.FirstCommand");
            //create push button from data
            var pb1 = ribbonPanel.AddItem(bData) as PushButton;
            //add image for button, with fallback of empty if not found
            var pb1Image = new BitmapImage(new Uri(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? string.Empty, "Resources", "BIM².Ico")));
            // quick exit for errors
            if (pb1 == null) return;
            pb1.LargeImage = pb1Image;
            //add tooltip info
            pb1.ToolTip = "Just an example of tooltip info you can include";
            //add image for tooltip
            ImageSource ttImage = pb1Image;
            pb1.ToolTipImage = ttImage;
            //add help for tooltip
            pb1.SetContextualHelp(new ContextualHelp(ContextualHelpType.Url, "https://bimsquared.com"));
        }
    }
}