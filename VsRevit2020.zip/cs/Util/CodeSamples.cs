#region Usings
using System;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace $safeprojectname$.Util
{
    public class CodeSamples
    {
        public void SelectionsExamples(UIDocument uidoc)
        {
            //get whats currently selected when command is pressed
            var sel = uidoc.Selection;

            //select elements manually
            //pick just one
            var eref = uidoc.Selection.PickObject(ObjectType.Element, "Select a Element");
            //pick multiple
            var erefs = uidoc.Selection.PickObjects(ObjectType.Element, "Select Elements");
        }
        public void ViewTemplateExample(Document doc, string templateViewName)
        {
            //set default null view template
            View viewTemplate = null;
            //search for passed viewtemplate
            try
            {
                //use collector to search viewtemplates for desired template
                viewTemplate = (from v in new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                                where v.IsTemplate && v.Name == templateViewName
                                select v).First();
            }
            //catch if it was not found
            catch (InvalidOperationException)
            {
                //let user know it doesnt exist
                var ts = new TaskDialog("View Template" + templateViewName + "Not Found")
                {
                    MainContent = " Could not find Tempate "
                };
                ts.Show();
            }
            //create transaction group to make things tidy.
            using (var viewTrans = new TransactionGroup(doc, "View Templates"))
            {
                //going to make two transactions 
                //create 1st trans to set template
                using (var templateView = new Transaction(doc, "Set Template"))
                {
                    //if the viewtemplate exist (just for clean code sake)
                    if (viewTemplate != null)
                    {
                        //start transaction
                        templateView.Start();
                        //set ViewTemplate to passed template
                        doc.ActiveView.ViewTemplateId = viewTemplate.Id;
                        templateView.Commit();
                    }
                    //if the viewtemplate doesnt exist, quick exit 
                    if (viewTemplate == null) return;
                    //create 2nd trans to set template back to null 
                    using (var nullviews = new Transaction(doc, "Set Null Template"))
                    {
                        //start transaction
                        nullviews.Start();
                        //Set ViewTemplate to null for VG use
                        doc.ActiveView.ViewTemplateId = new ElementId(-1);
                        //commit changes
                        nullviews.Commit();
                    }
                }
            }
        }
        public void HideElementCat(Document doc, View aview, Element e)
        {
            //using a transaction
            using (var ts = new Transaction(doc, "Hide Element"))
            {
                try
                {
                    //start trans
                    ts.Start();
                    //attempt to hide passed element
                    aview.SetCategoryHidden(e.Category.Id, true);
                    //commit changes
                    ts.Commit();
                }
                catch
                {
                    //undo changes
                    ts.RollBack();
                }
            }
        }
        public void CallRevitCommand(Document doc, UIApplication uiapp, RevitCommandId commandId)
        {
            // set default command if not specified
            commandId = RevitCommandId.LookupCommandId("ID_VIEW_CATEGORY_VISIBILITY");
            //create a named "offset" transaction in var doc
            using (var ts = new Transaction(doc, "Revit Command"))
            {
                //wrap transaction in a try
                try
                {
                    //start transaction
                    ts.Start();
                    var cmd = uiapp.CreateAddInCommandBinding(commandId);
                    uiapp.PostCommand(commandId);
                    ts.Commit();
                }
                //error handler
                catch (Exception ex)
                {
                    //show error message
                    TaskDialog.Show("Error", ex.Message);
                    //undo changes on error
                    ts.RollBack();
                }
            }
        }
    }
}
